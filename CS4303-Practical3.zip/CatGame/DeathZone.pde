

class DeathZone extends Tile{
    // private final Boolean collidable = Boolean.TRUE;
    // private float posX;
    // private float posY;

    public DeathZone(float posX, float posY){
        super(posX, posY);
        this.collidable = Boolean.TRUE;
    }


    //use super draw method
    // I think I will make the death zones water in the future
    //for now ......
    //override default draw function because death is invisible. Ha. ha. ha. ha. ha. ha.
    public void draw(float offsetX, float offsetY){
        //rect coord upper left corner x y width height
        // basic drawing, will replace with assets later
        //white
        // fill(255);
        // rect(this.posX + offsetX, this.posY + offsetY, Tile.tileLength, Tile.tileLength);
        //draw nothing for now
    }
}